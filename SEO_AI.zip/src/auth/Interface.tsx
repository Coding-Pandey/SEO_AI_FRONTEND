export interface GoogleUserDetails {
    username: string;
    email: string;
    oAuthId: string;
    role: string;
  }
  